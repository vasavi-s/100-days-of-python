print("Welcome to the Band Name Generator")
city =input("Which city you grew up in?\n")
pet=input("What is th name of pet?\n")
print("your band name  could be "+city+ " " + pet)